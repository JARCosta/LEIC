# Java Sockets exercise

This is the starting point for exercise on Java Sockets.
It is composed of two modules:
- [server](server/) - program that opens a socket and awaits for requests to process
- [client](client/) - program that opens a connection to the server and sends a request

See the README for each module.
Start at the [server](server/README.md) and then go to the [client](client/README.md).

----


## Authors

**Group T15**


ist199088 [João André Roque Costa](mailto:joaoarcosta@tecnico.ulisboa.pt)

ist1100598 [José Maria Vilar Gomes](mailto:jose.vilar.gomes@tecnico.ulisboa.pt)

ist196880 [João Pais Bettencourt](mailto:joao.pais.bettencourt@tecnico.ulisboa.pt)



----

For help, please contact:

[SD Faculty](mailto:leic-sod@disciplinas.tecnico.ulisboa.pt)
